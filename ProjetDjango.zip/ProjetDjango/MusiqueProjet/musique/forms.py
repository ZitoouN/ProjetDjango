from django.forms import ModelForm
from django.utils.translation import gettext_lazy as _
from . import models

class MusiqueForm(ModelForm):
    class Meta :
        model = models.Musique
        fields = ('titre', 'artiste','date_parution', 'min', 'sec', 'album', 'commentaire')
        labels = {
            'titre' : _('Nom du titre'),
            'artiste' : _('Artiste'),
            'date_parution' : _('Date de création'),
            'min' : _('Minutes'),
            'sec' : _('Secondes'),
            'album' : _('Album'),
            'commentaire' : _('Commentaire'),
        }

class AlbumForm(ModelForm):
    class Meta :
        model = models.Album
        fields = ('nom', 'artiste', 'date')
        labels = {
            'nom' : _('Nom'),
            'artiste' : _('Artiste'),
            'date' : _('Date de création'),
        }
