from django.db import models

# Create your models here.

class Musique(models.Model):
    titre = models.CharField(max_length=100)
    artiste = models.CharField(max_length=100)
    date_parution = models.DateField(blank = True, null = True)
    min = models.IntegerField(blank=False)
    sec = models.IntegerField(blank=False)
    album = models.ForeignKey("album", on_delete=models.CASCADE, default=None, blank=True)
    commentaire = models.TextField(null = True, blank = True)

    def __str__(self):
        return self.titre

    def dico(self):
        return {"titre":self.titre, "artiste":self.artiste, "date_parution":self.date_parution, "min":self.min, "sec":self.sec, "album":self.album, "commentaire":self.commentaire}

class Album(models.Model):
    nom = models.CharField(max_length=100)
    artiste = models.CharField(max_length=100)
    date = models.DateField(blank = True, null = True)

    def __str__(self):
        return self.nom

    def dico2(self):
        return {"nom":self.nom, "artiste":self.artiste, "date":self.date}